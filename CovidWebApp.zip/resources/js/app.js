import Vue from 'vue';

import Dashboard from './Dashboard';

new Vue(Dashboard).$mount('#app');
