<?php

namespace App\Exceptions;

use Exception;

class TelgramException extends Exception
{
    //
}
